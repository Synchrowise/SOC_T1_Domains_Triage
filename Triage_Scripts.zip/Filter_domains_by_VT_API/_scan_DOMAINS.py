import sys,codecs
import json
import requests
from pprint import pprint
import time
import datetime
import shutil
import os

original_sys_stdout = sys.stdout

def create_json_file(f,json_text):
	try:
		f=f+".json"
		sys.stdout = open(f, 'a')
		pprint(json_text)
		sys.stdout = original_sys_stdout
		
	except UnicodeEncodeError as error:
		print ('An encoding error occurred while outputing some json content into the .json file: %s\n' % error)
	
	
	

def create_folder(folder_name):	
	if not os.path.exists(folder_name):
		os.makedirs(folder_name)
	else:
		print("The folder to be created already exists\n")

def	copy_text_files_to_folder(folder_name):

	for text_file in os.listdir("."):
		if text_file.endswith(".txt"):
			shutil.copy(text_file,folder_name)
			
	shutil.copy("README",folder_name)


#Reading the json config file from parent folder
with open('../_config.json') as json_data_file:
	config = json.load(json_data_file)

	
folder="VT_"+"Start_time_"+str(datetime.datetime.now())[:-7].replace(":","-").replace(" ","_")
create_folder(folder)
			
url = 'https://www.virustotal.com/vtapi/v2/domain/report'

#Compute the number of lines in the file
num_lines = sum(1 for line in open("domains.txt"))

#Initiate a counter variable
i=1

#Initiate a counter to track the number of requests
j=0

print("Sleeping 60s before first API call\n")
time.sleep(60)

#open the file with read privilege
with open("domains.txt", "r") as ins:
	
	#Loop each line in the file
	for line in ins:
		
		if j == 4:
			#print("Sleeping 90s following VT free API limitation\n")
			time.sleep(90)
			j=0
			
		#if the counter doesn't correspond to the last line, cause \n doesn't exist in the last line
		if i < num_lines:
			#Truncate the last character from the line
			line=line[:-1]
		
		#print(line)
		
		#increment counter
		i=i+1
		
		#API call
		params = {'apikey':config["virustotal"]["api_key"],'domain':line}
		
		#print("API call for: "+line+" \n")
		response = requests.get(url, params=params)
		
		
		json_data = json.loads(response.text)
		
		create_json_file(line,json_data)
		
		#copy .json created file to folder
		shutil.copy(line+".json",folder)
		
		
		if 'Domain not found' in json_data['verbose_msg']:
			
			open("not_found.txt", 'a').write(line+"\n")
			print("The following domain is not found in VT database : "+line+"\n")
			
			
		else:
			
			#Output Categories
			
			with open("categories.txt", 'a') as categories:
				categories.write("\n\n")
				categories.write("\n\n"+line)
				
				
				categories.write("\n\t")
				
				if	('categories' in json_data) :
				
					if (json_data['categories']):
						categories.write("".join(str(json_data['categories']) ))
					
					if 'Forcepoint ThreatSeeker category' in json_data:
						categories.write("\n\tForcepoint ThreatSeeker category: ")
						categories.write("".join(str(json_data['Forcepoint ThreatSeeker category']) ))
						
					if 'BitDefender domain info' in json_data:
						categories.write("\n\tBitDefender domain info: ")
						categories.write("".join(str(json_data['BitDefender domain info']) ))
					
					if 'BitDefender category' in json_data:
						categories.write("\n\tBitDefender category: ")
						categories.write("".join(str(json_data['BitDefender category']) ))
						
					if 'Webutation domain info' in json_data:
						categories.write("\n\tWebutation domain info: ")
						categories.write("".join(str(json_data['Webutation domain info']) ))
				
			#Feed file with malicious domains according to VT
			
			if	('detected_downloaded_samples' in json_data) :
				if	( json_data['detected_downloaded_samples'] ) :
					open("positives.txt", 'a').write(line+"\n")
					print("The following domain has malicious downloads: "+line+"\n")
							
				
				
				elif ('detected_urls' in json_data):
					if	( json_data['detected_urls'] ) :
						open("positives.txt", 'a').write(line+"\n")
						print("The following domain has malicious urls: "+line+"\n")
				
				
			elif ('detected_urls' in json_data):
				if	( json_data['detected_urls'] ) :
					open("positives.txt", 'a').write(line+"\n")
					print("The following domain has malicious urls: "+line+"\n")
					
				

			#Feed another file with domains not detected as malicious by V.T
			
			if	(('detected_downloaded_samples' not in json_data) and ('detected_urls' not in json_data))   :
				open("negatives.txt", 'a').write(line+"\n")
				print("The following domain, as shown in VT, has no malicious urls or downloads : "+line+"\n")
				
						
			elif (('detected_downloaded_samples' in json_data) and ('detected_urls' not in json_data)):
				if (not json_data['detected_downloaded_samples']):
					open("negatives.txt", 'a').write(line+"\n")
					print("The following domain, as shown in VT, has no malicious urls or downloads : "+line+"\n")
				
					
			elif (('detected_downloaded_samples' not in json_data) and ('detected_urls' in json_data)):
				if (not json_data['detected_urls']):
					open("negatives.txt", 'a').write(line+"\n")
					print("The following domain, as shown in VT, has no malicious urls or downloads : "+line+"\n")
				
					
			else:
				if ((not json_data['detected_urls']) and (not json_data['detected_downloaded_samples'])) :
					open("negatives.txt", 'a').write(line+"\n")
					print("The following domain, as shown in VT, has no malicious urls or downloads : "+line+"\n")
				
		
		j=j+1


copy_text_files_to_folder(folder)


		
