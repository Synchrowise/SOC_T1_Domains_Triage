import sys,codecs
import requests
from pprint import pprint
import time
import datetime
import shutil
import os
import json

original_sys_stdout = sys.stdout

def create_xml_file(f,xml_text):
	try:
		f=f+".xml"
		sys.stdout = open(f, 'a')
		pprint(xml_text)
		sys.stdout = original_sys_stdout
		
	except UnicodeEncodeError as error:
		print ('An encoding error occurred while outputing some json content into the .json file: %s\n' % error)
	
	
	

def create_folder(folder_name):	
	if not os.path.exists(folder_name):
		os.makedirs(folder_name)
	else:
		print("The folder to be created already exists\n")

def	copy_text_files_to_folder(folder_name):

	for text_file in os.listdir("."):
		if text_file.endswith(".txt"):
			shutil.copy(text_file,folder_name)
			
	shutil.copy("README",folder_name)


#Reading the json config file from parent folder
with open('../_config.json') as json_data_file:
	config = json.load(json_data_file)
	


folder="URLVOID_"+"Start_time_"+str(datetime.datetime.now())[:-7].replace(":","-").replace(" ","_")
create_folder(folder)
			
url = "https://api.urlvoid.com/"+ config["urlvoid"]["api_id"]+"/"+config["urlvoid"]["api_key"]+"/host/"

#Compute the number of lines in the file
num_lines = sum(1 for line in open("domains.txt"))

#Initiate a counter variable
i=1

#Initiate a counter to track the number of requests
j=0

print("Sleeping 60s before first API call\n")
time.sleep(60)

#open the file with read privilege
with open("domains.txt", "r") as ins:
	
	#Loop each line in the file
	for line in ins:
		
		if j == 4:
			print("Sleeping 20s as Throttle\n")
			time.sleep(10)
			j=0
			
		#if the counter doesn't correspond to the last line, cause \n doesn't exist in the last line
		if i < num_lines:
			#Truncate the last character from the line
			line=line[:-1]
		
		#print(line)
		
		#increment counter
		i=i+1
		
		#API call
		response = requests.get(url+line+"/rescan/")
		
		print("waiting 35s while website updates reputation database for domain: "+line+"\n")
		time.sleep(35)
		
		#Fetching updated report
		xml_data = response.text
		
		create_xml_file(line,xml_data)
		
		#copy .xml created file to folder
		shutil.copy(line+".xml",folder)
		
		
		if str(xml_data).find("<detections>") != -1:
			open('positives.txt','a').write(line+"\n")
			print("This domain is flagged by at least one engine: "+line+"\n")
			
		elif str(xml_data).find("<action_result>ERROR") != -1:
			open('errors.txt','a').write(line+"\n")
			print("There was an error while retrieving reputation for this domain: "+line+"\n")
			
		else:
			open('negatives.txt','a').write(line+"\n")
			print("Up to date information about this domains shows no bad reputation: "+line+"\n")
			
			
		j=j+1


copy_text_files_to_folder(folder)

stats= requests.get("https://api.urlvoid.com/"+ config["urlvoid"]["api_id"]+"/"+config["urlvoid"]["api_key"]+"/stats/remained/")
		
open("remained_requests.txt","a").write(str(stats.text[67:-59])+"\n")
		
