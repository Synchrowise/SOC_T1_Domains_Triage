import requests
from lxml import etree, html
import time
import datetime
import shutil
import os

def create_folder(folder_name):	
	if not os.path.exists(folder_name):
		os.makedirs(folder_name)
	else:
		print("The folder to be created already exists\n")


def	copy_text_files_to_folder(folder_name):

	for text_file in os.listdir("."):
		if text_file.endswith(".txt"):
			shutil.copy(text_file,folder_name)
			
	shutil.copy("README",folder_name)
			

folder="QUTTERA_"+"Start_time_"+str(datetime.datetime.now())[:-7].replace(":","-").replace(" ","_")
create_folder(folder)


#Compute the number of lines in the file
num_lines = sum(1 for line in open("domains.txt"))

#Initiate a counter variable
i=1

print("Sleeping 60s before the first request\n")
time.sleep(60)

with open("domains.txt","r") as domains:

	for domain in domains:
		
		
		#if the counter doesn't correspond to the last line
		if i < num_lines:
			#Truncate the last character from the line
			domain=domain[:-1]
		
		#Request last report
		print("Fetching last report for: "+domain+" \n")
		page=requests.get("http://quttera.com/detailed_report/"+domain)
		
		#Give time to updating
		print("Sleeping 15s as throttle\n")
		time.sleep(15)
		
		#Constructing xml tree
		tree = html.fromstring(page.content)

		if (tree.xpath('/html/body/div[2]/div/div[1]/div/h3')):
			print("report not found for domain: "+domain+" Trying re-scan...\n")
			updated_page=requests.get("http://quttera.com/sitescan/"+domain)
			print("Sleeping 60s for page refresh and redirection\n")
			time.sleep(60)
			page=requests.get("http://quttera.com/detailed_report/"+domain)
			tree = html.fromstring(page.content)
			
			
		if (tree.xpath('/html/body/div[2]/div/div[1]/div/h3')):
			print("Report not found for domain: "+domain+" even after re-scan\n")
			open("not_found.txt","a").write(domain+"\n")
		
		

		else:
		
			#Seeking the xml object representing the main response
			main_response=tree.xpath('//*[@id="ResultSummary"]/div/div[1]/h4/text()')
			
			if ("".join(main_response)=='Warning: This Website Is Blacklisted!'):
				print("The website: "+domain+" is blacklisted\n")
				open("blacklisted.txt","a").write(domain+"\n")

			elif ("".join(main_response)=='No Malware Detected By Free Online Website Scan On This Website.'):
				print("No Malware Detected By quttera on the website: "+domain+"\n")
				open("no_malware.txt","a").write(domain+"\n")
				
			elif ("".join(main_response)=='Warning: Malware Detected On This Website!'):
				print("Warning. Malware Detected On The Website: "+domain+"\n")
				open("malware.txt","a").write(domain+"\n")
			
			elif ("".join(main_response)=='Alert: Suspicious Content Detected On This Website!'):
				print("Suspicious Content Detected On The Website!: "+domain+"\n")
				open("suspicious.txt","a").write(domain+"\n")
			
			else:
				print("There was an error while scanning domain: "+domain+"\nThe returned main response is: "+"".join(main_response)+"\n")
				open("errors.txt","a").write(domain+"\n")
			
		#increment counter
		i=i+1

copy_text_files_to_folder(folder)